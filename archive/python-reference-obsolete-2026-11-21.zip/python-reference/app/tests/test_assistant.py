import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from trio_mix import config as C
from trio_mix.assistant import MixAssistant
from trio_mix.dsp import ChannelFeatures
from trio_mix.osc import SimConsole


def feat(rms=-30.0, peak=-20.0, fb=None, contrast=None):
    if contrast is None:
        contrast = 24.0 if fb else 6.0
    return ChannelFeatures(rms_dbfs=rms, peak_dbfs=peak, fb_freq=fb, contrast_db=contrast)


class TestClip(unittest.TestCase):
    def test_clip_trims_preamp(self):
        con = SimConsole()
        a = MixAssistant(con)
        before = a.gain_db[3]
        a.on_features(3, feat(peak=-0.5), now=1.0)
        self.assertLess(a.gain_db[3], before)
        self.assertEqual(a.gain_db[3], before + C.CLIP_TRIM_DB)

    def test_no_clip_when_safe(self):
        con = SimConsole()
        a = MixAssistant(con)
        a.on_features(3, feat(peak=-12.0), now=1.0)
        self.assertEqual(a.gain_db[3], a.nominal_gain[3])

    def test_clip_recovers_when_clean(self):
        con = SimConsole()
        a = MixAssistant(con)
        a.on_features(3, feat(peak=-0.5), now=1.0)
        trimmed = a.gain_db[3]
        a.on_features(3, feat(peak=-30.0), now=1.0 + C.CLIP_RECOVER_S + 1)
        self.assertGreater(a.gain_db[3], trimmed)


class TestFeedback(unittest.TestCase):
    def _drive(self, a, ch, freqs_levels):
        for f, lvl in freqs_levels:
            a.on_features(ch, feat(rms=lvl, peak=-20, fb=f), now=0.0)

    def test_rising_stable_ring_is_notched(self):
        con = SimConsole()
        a = MixAssistant(con)
        self._drive(a, 2, [(2500, -30 + i) for i in range(8)])
        self.assertTrue(con.notches.get(2))
        self.assertAlmostEqual(con.notch_freqs(2)[0], 2500, delta=1)

    def test_steady_note_not_notched(self):
        con = SimConsole()
        a = MixAssistant(con)
        self._drive(a, 1, [(220, -25) for _ in range(12)])
        self.assertFalse(con.notches.get(1))

    def test_wandering_freq_not_notched(self):
        con = SimConsole()
        a = MixAssistant(con)
        self._drive(a, 1, [(220 + 30 * i, -25 + i) for i in range(10)])
        self.assertFalse(con.notches.get(1))

    def test_watchlist_reacts_sooner(self):
        con_w = SimConsole()
        aw = MixAssistant(con_w)
        aw.watch_freqs = [2500]
        con_n = SimConsole()
        an = MixAssistant(con_n)
        seq = [(2500, -30 + i) for i in range(4)]
        for f, lvl in seq:
            aw.on_features(2, feat(rms=lvl, fb=f), now=0.0)
            an.on_features(2, feat(rms=lvl, fb=f), now=0.0)
        self.assertTrue(con_w.notches.get(2))
        self.assertFalse(con_n.notches.get(2))

    def test_harmonic_tone_needs_more_sustain(self):
        con_p = SimConsole()
        ap = MixAssistant(con_p)
        con_h = SimConsole()
        ah = MixAssistant(con_h)
        for i in range(6):
            lvl = -30 + i
            ap.on_features(
                2,
                ChannelFeatures(rms_dbfs=lvl, peak_dbfs=-20, fb_freq=2500, harmonicity=0.0),
                now=0.0,
            )
            ah.on_features(
                2,
                ChannelFeatures(rms_dbfs=lvl, peak_dbfs=-20, fb_freq=2500, harmonicity=1.0),
                now=0.0,
            )
        self.assertTrue(con_p.notches.get(2))
        self.assertFalse(con_h.notches.get(2))

    def test_reset_clears_notches(self):
        con = SimConsole()
        a = MixAssistant(con)
        self._drive(a, 2, [(2500, -30 + i) for i in range(8)])
        self.assertTrue(con.notches.get(2))
        a.reset_notches()
        self.assertFalse(con.notches.get(2))
        self.assertEqual(a.used_notch_band[2], 0)


class TestRides(unittest.TestCase):
    def test_vocal_ride_pushes_toward_target(self):
        con = SimConsole()
        a = MixAssistant(con)
        a.enabled["vocal_ride"] = True
        a.lead_target = -6.0
        now = 0.0
        for _ in range(20):
            a.on_features(C.LEAD_VOCAL_CH, feat(rms=-30.0), now=now)
            now += 0.3
        self.assertGreater(a.fader_db[C.LEAD_VOCAL_CH], 0.0)
        self.assertLessEqual(a.fader_db[C.LEAD_VOCAL_CH], C.FADER_MAX_DB)

    def test_vocal_ride_respects_deadband(self):
        con = SimConsole()
        a = MixAssistant(con)
        a.enabled["vocal_ride"] = True
        a.lead_target = -6.0
        now = 0.0
        for _ in range(10):
            a.on_features(C.LEAD_VOCAL_CH, feat(rms=-6.0), now=now)
            now += 0.3
        self.assertAlmostEqual(a.fader_db[C.LEAD_VOCAL_CH], 0.0, delta=1.01)

    def test_balance_capture_and_hold(self):
        con = SimConsole()
        a = MixAssistant(con)
        a.fader_db[5] = 0.0
        a.capture_balance({5: -20.0, 7: -18.0})
        self.assertAlmostEqual(a.balance_targets[5], -20.0, places=1)
        a.enabled["balance"] = True
        now = 0.0
        start = a.fader_db[5]
        for _ in range(10):
            a.on_features(5, feat(rms=-28.0), now=now)
            now += 1.1
        self.assertNotEqual(a.fader_db[5], start)


if __name__ == "__main__":
    unittest.main()
